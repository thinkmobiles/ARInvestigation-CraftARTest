//
//  CraftARPods.h
//  CraftARPods
//
//  Created by Luis Martinell Andreu on 17/11/14.
//
//

#import <UIKit/UIKit.h>

#import "AFNetworking.h"
#import "AFDownloadRequestOperation.h"

//! Project version number for CraftARPods.
FOUNDATION_EXPORT double CraftARPodsVersionNumber;

//! Project version string for CraftARPods.
FOUNDATION_EXPORT const unsigned char CraftARPodsVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <CraftARPods/PublicHeader.h>


