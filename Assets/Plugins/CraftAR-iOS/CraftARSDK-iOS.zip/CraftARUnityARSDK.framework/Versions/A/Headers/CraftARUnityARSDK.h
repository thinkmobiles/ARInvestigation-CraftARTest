//
//  CraftARUnityARSDK.h
//  CraftARUnityARSDK
//
//  Created by Catchoom on 27/11/15.
//  Copyright © 2015 Catchoom. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for CraftARUnityARSDK.
FOUNDATION_EXPORT double CraftARUnityARSDKVersionNumber;

//! Project version string for CraftARUnityARSDK.
FOUNDATION_EXPORT const unsigned char CraftARUnityARSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <CraftARUnityARSDK/PublicHeader.h>


